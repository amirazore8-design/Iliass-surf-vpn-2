package com.vpnng.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebView
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    private lateinit var web: WebView

    inner class Bridge {
        @JavascriptInterface fun clip(): String {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            return cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
        }
        @JavascriptInterface fun fetch(u: String): String {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 10000; c.readTimeout = 15000
            c.setRequestProperty("User-Agent", "VpnNG/1.0")
            return c.inputStream.bufferedReader().use { it.readText() }
        }
        @JavascriptInterface fun open(u: String) {
            runOnUiThread { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#07140f")
        window.navigationBarColor = Color.parseColor("#12241c")
        web = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#07140f"))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            webChromeClient = object : WebChromeClient() {
                override fun onJsAlert(v: WebView, url: String, m: String, r: JsResult): Boolean {
                    AlertDialog.Builder(this@MainActivity).setMessage(m)
                        .setPositiveButton("OK") { _, _ -> r.confirm() }.setOnCancelListener { r.cancel() }.show()
                    return true
                }
                override fun onJsConfirm(v: WebView, url: String, m: String, r: JsResult): Boolean {
                    AlertDialog.Builder(this@MainActivity).setMessage(m)
                        .setPositiveButton("OK") { _, _ -> r.confirm() }
                        .setNegativeButton("Annuler") { _, _ -> r.cancel() }.show()
                    return true
                }
            }
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
    }

    override fun onBackPressed() { super.onBackPressed() }
}
