# VPN NG
1. Creez un depot GitHub et envoyez tout ce dossier (y compris .github).
2. Onglet Actions > Build APK (demarre seul, ou Run workflow).
3. Telechargez l artefact VpnNG-debug-apk, decompressez, installez l APK.
